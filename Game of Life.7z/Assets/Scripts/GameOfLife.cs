using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class GameOfLife : MonoBehaviour
{
    [SerializeField] int gridSize = 10;
    [SerializeField] float tickTime = 1;

    bool[][] grid;
    Dictionary<Vector2Int, int> neighbours = new Dictionary<Vector2Int, int>();
    Vector2Int[] directions = new Vector2Int[] {
        Vector2Int.left,
        Vector2Int.right,
        Vector2Int.up,
        Vector2Int.down,
        Vector2Int.one,
        new Vector2Int(1,-1),
        new Vector2Int(-1, 1),
        new Vector2Int(-1, -1)};


    private void Awake()
    {
        grid = new bool[gridSize][];
        for (int i = 0; i < gridSize; i++)
        {
            grid[i] = new bool[gridSize];
        }
    }
    private void Start()
    {
        populate();
        StartCoroutine(Tick());
    }

    private void Update()
    {
        visuals();
    }

    private void populate()
    {
        for (int x = 0; x < grid.Length; x++)
        {
            for (int y = 0; y < grid[x].Length; y++)
            {
                if (Random.Range(0, 11) > 2)
                {
                    grid[x][y] = true;
                }
            }
        }



        //grid[510][510] = true;
        //grid[511][510] = true;
        //grid[511][512] = true;
        //grid[513][511] = true;
        //grid[514][510] = true;
        //grid[515][510] = true;
        //grid[516][510] = true;
    }

    IEnumerator Tick()
    {   
        CountNeighbours();
        ApplyRules();
        yield return new WaitForSeconds(tickTime);
        StartCoroutine(Tick());
    }

    private void CountNeighbours()
    {
        for (int x = 0; x < gridSize; x++)
        {
            for (int y = 0; y < gridSize; y++)
            {
                if (grid[x][y])
                {
                    foreach (Vector2Int direction in directions)
                    {
                        Vector2Int cell = new Vector2Int(x, y);
                        if (neighbours.ContainsKey(cell + direction))
                        {
                            neighbours[cell + direction] += 1;
                        }
                        else
                        {
                            neighbours.Add(cell + direction, 1);
                        }
                    }
                }
            }
        }
    }

    private void ApplyRules()
    {
        for (int x = 0; x < gridSize; x++)
        {
            for (int y = 0; y < gridSize; y++)
            {
                Vector2Int key = new Vector2Int(x, y);
                if (neighbours.ContainsKey(key))
                {
                    //Debug.Log(cell);
                    switch (neighbours[key])
                    {
                        //case < 2:
                        //    grid[x][y] = false;
                        //    break;
                        case 2:
                            break;
                        case 3:
                            grid[x][y] = true;
                            break;
                        //case > 3:
                        //    grid[x][y] = false;
                        //    break;
                        default:
                            grid[x][y] = false;
                            break;
                    }
                }
                else
                {
                    if (x < 0 || x > gridSize - 1) { continue; }
                    if (y < 0 || y > gridSize - 1) { continue; }
                    grid[x][y] = false;
                }
            }
        }
        
        neighbours = new Dictionary<Vector2Int, int>();
    }


    private void visuals()
    {
        for (int x = 0; x < gridSize; x++)
        {
            for (int y = 0; y < gridSize; y++)
            {
                if (grid[x][y])
                {
                    Debug.DrawLine(new Vector2(x - 0.5f, y + 0.5f), new Vector2(x + 0.5f, y - 0.5f), Color.white);
                    Debug.DrawLine(new Vector2(x + 0.5f, y + 0.5f), new Vector2(x - 0.5f, y - 0.5f), Color.white);
                }
            }
        }
    }
}