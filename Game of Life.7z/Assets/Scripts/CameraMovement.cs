using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using UnityEditor.Experimental.GraphView;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    Camera mainCamera;

    public float cameraSpeed;
    
    public float zoomSpeed;

    bool movedLastFrame = false;
    Vector2 mouseLastFrame;
    float cameraSize;

    private void Awake()
    {
        mainCamera = Camera.main;
        cameraSize = mainCamera.orthographicSize;
    }

    private void Update()
    {
        Zoom();
        MoveCamera();
    }

    private void MoveCamera()
    {
        if (Input.GetKey(KeyCode.Mouse2))
        {
            if (movedLastFrame)
            {
                Vector2 mousePos = Input.mousePosition;
                transform.position -= (Vector3)(cameraSize * cameraSpeed * Time.unscaledDeltaTime * (mousePos - mouseLastFrame));
                mouseLastFrame = mousePos;
            }
            else
            {
                movedLastFrame = true;
                mouseLastFrame = Input.mousePosition;
            }
        }
        else
        {
            movedLastFrame = false;
        }
    }

    private void Zoom()
    {
        float mouseScroleDetlaY = Input.mouseScrollDelta.y * Time.unscaledDeltaTime;
        if (mouseScroleDetlaY != 0)
        {
            cameraSize -= mouseScroleDetlaY * zoomSpeed;
            cameraSize = Mathf.Clamp(cameraSize, 1f, 10000f);
            mainCamera.orthographicSize = cameraSize;
        }
    }
}