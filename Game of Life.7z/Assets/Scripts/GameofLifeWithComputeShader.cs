using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Device;

public class GameofLifeWithComputeShader : MonoBehaviour
{
    [SerializeField] 
    ComputeShader gofComputeShader;
    ComputeBuffer gofResultComputeBuffer;
    RenderTexture gofRenderTexture;
    Texture2D gofTexture;
    int populateKernal;
    int gofKernel;
    [SerializeField] 
    SpriteRenderer spriteRenderer;

    [SerializeField, Tooltip("Will be multiplied by thread dimension length")] 
    int gridAxisLength;
    int gridAxisLengthMult;
    Rect gridRect;
    [Range(0, 1)]
    public float spawnChanse;
    [Range(0.0001f,2f)] 
    public float TickSpeed;
    [SerializeField]
    bool Playing;
    
    private void Awake()
    {
        populateKernal = gofComputeShader.FindKernel("Populate");
        gofKernel = gofComputeShader.FindKernel("GoF");
        initializeGrid(gridAxisLength);
    }

    private void Start()
    {
        if (Playing)
        {
            StartGof(gridAxisLength);
        }
    }

    public void StartGof(int axisLength)
    {
        gridAxisLength = axisLength;
        initializeGrid(gridAxisLength);
        ComputeWithCompute(populateKernal);
        StopAllCoroutines();
        StartCoroutine(Tick());
    }

    private void OnDestroy()
    {
        GarbageCollect();
    }


    private void OnDisable()
    {
        GarbageCollect();
    }

    private void initializeGrid(int axisLenght)
    {
        gridAxisLengthMult = axisLenght * 8;
        gofResultComputeBuffer = new ComputeBuffer(gridAxisLengthMult * gridAxisLengthMult, sizeof(int));
        gridRect = new Rect(0, 0, gridAxisLengthMult, gridAxisLengthMult);

        gofRenderTexture = new RenderTexture(gridAxisLengthMult, gridAxisLengthMult, 0, RenderTextureFormat.ARGB32, RenderTextureReadWrite.Linear)
        {
            enableRandomWrite = true,
        };
        gofRenderTexture.Create();
        gofTexture = new Texture2D(gridAxisLengthMult, gridAxisLengthMult, TextureFormat.ARGB32, -1, false)
        {
            filterMode = FilterMode.Point,
        };
    }

    private void GarbageCollect()
    {
        gofResultComputeBuffer.Release();
        gofRenderTexture.Release();
    }
    private void ComputeWithCompute(int kernel)
    {
        gofComputeShader.SetTexture(kernel, "Texture", gofRenderTexture);
        gofComputeShader.SetBuffer(kernel, "Result", gofResultComputeBuffer);
        gofComputeShader.SetInt("_GridAxisLength", gridAxisLengthMult);
        gofComputeShader.SetFloat("_SpawnChanse", spawnChanse);

        gofComputeShader.Dispatch(kernel, gridAxisLength, gridAxisLength, 1);

        // TODO dont make sprites dum dum
        Graphics.CopyTexture(gofRenderTexture, 0, 0, gofTexture, 0, 0);
        spriteRenderer.sprite = Sprite.Create(gofTexture, gridRect, Vector2.zero, 1f);
    }

    IEnumerator Tick()
    {
        yield return new WaitForSeconds(TickSpeed);
        ComputeWithCompute(gofKernel);
        StartCoroutine(Tick());
    }
}