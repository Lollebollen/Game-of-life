using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuHandler : MonoBehaviour
{
    GameofLifeWithComputeShader gof;
    CameraMovement cam;
    [SerializeField] Slider sizeSlider;
    [SerializeField] Slider tickSlider;    
    [SerializeField] Slider zoomSlider;
    [SerializeField] Slider cameraSlider;
    [SerializeField] Slider spawnChanseSlider;
    [SerializeField] int axisLenght;

    bool puased = false;

    public void ChangeScene(int scene)
    { 
        SceneManager.LoadScene(scene);
    }

    public void Quit()
    {
        Application.Quit();
        Debug.Log("Quit was called");
    }

    public void StartGoL()
    {
        if (gof == null)
        {
            gof = FindAnyObjectByType<GameofLifeWithComputeShader>();
        }
        gof.StartGof(axisLenght);
    }

    public void ChangeAxisLenght()
    {
        axisLenght = Mathf.RoundToInt(sizeSlider.value);
    }

    public void ChangeTickSpeed()
    {
        gof.TickSpeed = tickSlider.value;
    }
    public void ChangeSpawnChanse()
    {
        gof.spawnChanse = spawnChanseSlider.value;
    }
    
    public void ChangeZoomSpeed()
    {
        if (cam == null)
        {
            cam = FindAnyObjectByType<CameraMovement>();
        }
        cam.zoomSpeed = zoomSlider.value;
    }
    public void ChangeCamSpeed()
    {
        if (cam == null)
        {
            cam = FindAnyObjectByType<CameraMovement>();
        }
        cam.cameraSpeed = cameraSlider.value;
    }

    public void PauseUnpause()
    {
        if (puased)
        {
            Time.timeScale = 1.0f;
            puased = false;
        }
        else
        {
            Time.timeScale = 0;
            puased = true;
        }
    }
}
