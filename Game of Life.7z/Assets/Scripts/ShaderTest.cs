using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShaderTest : MonoBehaviour
{
    //                                  :::::::::using a computeshader to randomise a bunch of random values::::::::

    [SerializeField] Transform cubePrefab;
    [SerializeField] ComputeShader computeShader;

    ComputeBuffer computeBuffer;

    [SerializeField] int cubesPerAxis;
    [SerializeField] int repitisons;

    Transform[] cubes;
    float[] cubePositions;


    [SerializeField] bool useShader;

    private void Awake()
    {
        computeBuffer = new ComputeBuffer(cubesPerAxis * cubesPerAxis, sizeof(float));
    }

    private void Start()
    {
        CreateGrid();
    }

    private void OnDestroy()
    {
        computeBuffer.Release();
    }

    private void CreateGrid()
    {
        int gridSize = cubesPerAxis * cubesPerAxis;
        cubes = new Transform[gridSize];
        cubePositions = new float[gridSize];
        for (int x = 0, i = 0; x < cubesPerAxis; x++)
        {
            for (int y = 0; y < cubesPerAxis; y++, i++)
            {
                cubes[i] = Instantiate(cubePrefab, transform);
                cubes[i].transform.position = new Vector3(x, y, 0);
            }
        }

        StartCoroutine(UpdateGrid(gridSize));
    }

    private void UseCPU(int gridSize)
    {
        for (int i = 0; i < gridSize; i++)
        {
            for (int j = 0; j < repitisons; j++)
            {
                cubePositions[i] = Random.Range(-1.0f, 1.0f);
            }
        }
    }

    private void UseGPU()
    {
        computeShader.SetBuffer(0, "_Positions", computeBuffer);

        computeShader.SetInt("_CubesPerAxis", cubesPerAxis);
        computeShader.SetInt("_Repetitions", repitisons);
        computeShader.SetFloat("_Time", Time.deltaTime);

        int workgroups = cubesPerAxis * 8;
        computeShader.Dispatch(0, workgroups, workgroups, 1);

        computeBuffer.GetData(cubePositions);
    }

    IEnumerator UpdateGrid(int gridSize)
    {
        while (true)
        {
            if (useShader)
            {
                UseGPU();
            }
            else
            {
                UseCPU(gridSize);
            }

            for (int i = 0; i < gridSize; i++)
            {
                cubes[i].localPosition = new Vector3(cubes[i].localPosition.x, cubes[i].localPosition.y, cubePositions[i]);
            }

            yield return new WaitForSeconds(1);
        }
    }

    //                                              :::::::::computeshader making a texture:::::::::

    //[SerializeField] ComputeShader shader;
    //RenderTexture renderTexture;
    //private void OnRenderImage(RenderTexture source, RenderTexture destination)
    //{
    //    if (renderTexture == null)
    //    {
    //        renderTexture = new RenderTexture(Screen.width, Screen.height, 0, RenderTextureFormat.ARGB32, RenderTextureReadWrite.Linear);
    //        renderTexture.enableRandomWrite = true;
    //        renderTexture.Create();
    //    }
    //    int kernal = shader.FindKernel("CSMain");
    //    shader.SetTexture(kernal, "Result", renderTexture);
    //    int WorkgroupsY = Mathf.CeilToInt(Screen.height / 8f);
    //    int WorkgroupsX = Mathf.CeilToInt(Screen.width / 8f);
    //    shader.Dispatch(kernal, WorkgroupsX, WorkgroupsY, 1);
    //    Graphics.Blit(renderTexture, destination);
    //}
}
